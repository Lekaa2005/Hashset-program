package practise;
import java.util.HashSet;
public class hashsets {
	public static void main(String[] args) {
		HashSet<String> name=new HashSet<>();
		name.add("deva");
		name.add("baru");
		name.add("shan");
		name.add("sathya");
		name.add("abi");
		name.add("baru");
		System.out.println("The Students are :");
		for(String n : name) {
			System.out.println(n);
		}
	}
}
